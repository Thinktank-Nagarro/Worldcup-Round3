package pojo;

public class Jsonschema {
        public String getFirstName) {
            return firstname;
        }

    public String getLastName) {
        return lastname;
    }

    public int getID) {
        return ID;
    }
    public String getcity) {
        return city;
    }
    public String getState {
        return state;
    }
    public String getPincode) {
        return pincode;
    }

    public void setGetFirstName(String getFirstName) {
        this.getFirstName = getFirstName;
    }

    public void setGetLastName(String getLastName) {
        this.getLastName = getLastName;
    }

    public void setGetID(int getID) {
        this.getID = getID;
    }

    public void setGetcity(String getcity) {
        this.getcity = getcity;
    }

    public void setGetState(String getState) {
        this.getState = getState;
    }

    public void setGetPincode(String getPincode) {
        this.getPincode = getPincode;
    }

    private String FirstName;
    private String LastName;
    private int ID;
    private String City;
    private String State;
    private int Pincode;

    public String getDepartname() {
        return Departname;
    }

    public void setDepartname(String departname) {
        Departname = departname;
    }

    public int getDepartmentid() {
        return Departmentid;
    }

    public void setDepartmentid(int departmentid) {
        Departmentid = departmentid;
    }

    private String Departname;
    private int Departmentid;



        @Override
        public String toString() {
            return ("{\n" +
                    "\"firstname\" : \"Test\",\n" +
                    "\"lastname\" : \"User\",\n" +
                    "\"id\" : 101,\n" +
                    "\"address\": {\n" +
                    "\"city\" : \"Gurugram\",\n" +
                    "\"state\" : \"Haryana\",\n" +
                    "\"pincode\" : \"122015\"\n" +
                    "},\n" +
                    "\"department\" : [\n" +
                    "{\n" +
                    "\"id\" : 21,\n" +
                    "\"name\" : \"Administration\"\n" +
                    "},\n" +
                    "{\n" +
                    "\"id\" : 22,\n" +
                    "\"name\" : \"Payroll\"\n" +
                    "}\n" +
                    "]\n" +
                    "}");
        }

    }


