package stepDefinations;
import Helper.Utils;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Test;

import java.io.IOException;


public class ProblemAPI  extends Utils {
    private static String token;
    private Response response;
    private RequestSpecification request;
    public APIResources resource;
    public static int dataList;


    @Test

    public void json_schema_with() throws IOException {
        request = RestAssured.given().log().all().spec(requestSpecification())
                .body(data.Jsonschema.toString());
      String firstname =   request.get(getFirstName);
        String getLastName = request.get(getLastName);
        int getID = Integer.parseInt(request.get(getid);
        String city =   request.get(Address[0].getcity);
        String state =   request.get(Address[1].getstate);

        int getPincode = Integer.parseInt(request.get(Address[2].getpincode);
        int getdepartmentid = Integer.parseInt(request.get(Department[0].getid);
        String getdepartmentname=   request.get(department[1].getname);

    }
}
