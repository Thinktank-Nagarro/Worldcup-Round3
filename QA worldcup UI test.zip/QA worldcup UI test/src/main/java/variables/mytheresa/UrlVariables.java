package variables.mytheresa;

public final class UrlVariables {
	public static final String BASE_URL = "https://www.mytheresa.com/en-de/";

}
