package variables.mytheresa;

public final class UserVariables {
	public static final String USER_FIRST_NAME = "First Name";
	public static final String USER_LAST_NAME = "Last Name";
	public static final String USER_EMAIL = "example@gmail.com";
	public static final String USER_PASSWORD = "123456pass";
	public static final String USER_NEW_PASSWORD = "pass123456";
	
}
