package testcases.makemytrip.;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import objectRepository.booking.*;

import java.util.List;

public class  makemytriptest{
    WebDriver driver;
    FlightticketPage fp = new FlightticketPage();

    @BeforeTest
    public void beforeTest() {
        System.setProperty("webdriver.chrome.driver","E:\\Program Files\\Selenium Software\\chromedriver_win32\\chromedriver.exe");
        driver=new ChromeDriver();
        driver.get("https://www.makemytrip.com/");
        driver.manage().window().maximize();
        fp=new FlightPagePOM(driver);
    }

    @Test(priority=1)
    public void flightsSearch() {
        fp.clickFlightTab();
    }

    @Test(priority=2)
    public void roundTrip() {
        fp.clickOnRoundTrip();
    }

    @Test(priority=3)
    public void cities() {
        fp.cities("Delhi", "Benga");
    }

    @Test(priority=4)
    public void dates() {
        fp.dates();
    }

    @Test(priority=5)
    public void travellersAndClass() {
        fp.travellersAndClass();
    }

    @Test(priority=6)
    public void search() {
        fp.search();
    }

    @Test(priority=7)
    public void selectFlight() {
        fp.flights();
    }
    // To print first nd last flight of the day
List<WebElement> datalist = driver.findElements(By.xpath("//div[@class='makeFlex simpleow']"));
   int count = datalist.size();
    for(int i=0; i<count, i++)
    {
       System.out.println(datalist.get(0).getText());
        System.out.println(datalist.get(count).getText());
    }

    // To find the flight with one stop, two stop or three stop
    List<WebElement> nonstoplist = driver.findElements(By.xpath("//*[text()='Non Stop']"));
    System.out.println("Length of non stop flight is" + nonstoplist.length());;

    List<WebElement> onestoplist = driver.findElements(By.xpath("//*[text()='1 Stop']"));
    System.out.println("Length of one stop flight is" + onestoplist.length());;
            }


